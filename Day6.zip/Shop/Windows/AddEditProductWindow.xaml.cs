﻿using Shop.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Shop.Windows
{
    /// <summary>
    /// Логика взаимодействия для AddEditProductWindow.xaml
    /// </summary>
    public partial class AddEditProductWindow : Window
    {
        private Product _product;
        private Entities _entities;

        public AddEditProductWindow(Product product, Entities entities)
        {
            InitializeComponent();

            _product = product;
            _entities = entities;

            if (_product.Article != string.Empty)
            {
                Title = "Окно редактирования";

                ArticleInput.Text = _product.Article;
                NameInput.Text = _product.Name;
                DescriptionInput.Text = _product.Description;
                PriceInput.Text = _product.Price.ToString();
            }
            else
            {
                Title = "Окно добавления";
            }
        }

        private void ApplyButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }

        private void DenyButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
