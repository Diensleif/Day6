﻿using Shop.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Shop.Windows
{
    /// <summary>
    /// Логика взаимодействия для ProductWindow.xaml
    /// </summary>
    public partial class ProductWindow : Window
    {
        private User _user;
        private Entities _entities = new Entities();

        public ProductWindow(int userId)
        {
            InitializeComponent();

            FilterInput.ItemsSource = _entities.Manufacturer.Select(x => x.Name).ToList();

            SortInput.ItemsSource = new List<string>()
            {
                "Без сортировки",
                "По возрастанию цены",
                "По убыванию цены"
            };

            if (userId == 0)
            {
                FullNameOutput.Text = "Гость";
            }
            else
            {
                _user = _entities.User.First(x => x.Id == userId);
                FullNameOutput.Text = $"{_user.Surname} {_user.Name} {_user.Patronymic}";

                if (_user.Role.Name == "Администратор")
                {
                    AddButton.Visibility = Visibility.Visible;
                    EditButton.Visibility = Visibility.Visible;
                    DeleteButton.Visibility = Visibility.Visible;
                }
            }

            Products.Items.Clear();
            Products.ItemsSource = _entities.Product.ToList();
            CountOutput.Text = $"{_entities.Product.Count()}/{_entities.Product.Count()}";
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var addEditProductWindow = new AddEditProductWindow(
                new Product() { Article = string.Empty },
                _entities);
            if (addEditProductWindow.ShowDialog() == true)
            {
                RefreshProducts(SearchInput.Text, FilterInput.Text, SortInput.Text);
            }
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            var product = Products.SelectedItem as Product;

            if (product == null)
            {
                MessageBox.Show("Сначала выберите товар",
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
                return;
            }
            else
            {
                var addEditProductWindow = new AddEditProductWindow(product, _entities);
                if (addEditProductWindow.ShowDialog() == true)
                {
                    RefreshProducts(SearchInput.Text, FilterInput.Text, SortInput.Text);
                }
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var product = Products.SelectedItem as Product;

            if (product == null)
            {
                MessageBox.Show("Сначала выберите товар",
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
                return;
            }
            else
            {
                if (product.OrderProduct.Count() > 0)
                {
                    MessageBox.Show("Товар нельзя удалить,\n" +
                        "так как он задействован в заказе",
                        "Ошибка",
                        MessageBoxButton.OK,
                        MessageBoxImage.Error);
                    return;
                }

                if (MessageBox.Show("Вы уверены?",
                    "Ошибка",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning) == MessageBoxResult.Yes)
                {
                    _entities.Product.Remove(product);
                    _entities.SaveChanges();

                    RefreshProducts(SearchInput.Text, FilterInput.Text, SortInput.Text);
                }
            }
        }

        private void RefreshProducts(string search, string filter, string sort)
        {
            var products = _entities.Product.AsEnumerable();

            if (!string.IsNullOrEmpty(search))
            {
                products = products.Where(x =>
                x.Article.Contains(search) ||
                x.Name.Contains(search) ||
                x.Description.Contains(search) ||
                x.Manufacturer.Name.Contains(search) ||
                x.Price.ToString().Contains(search) ||
                x.Count.ToString().Contains(search));
            }

            if (!string.IsNullOrEmpty(filter))
            {
                if (filter != "Все производители")
                {
                    products = products.Where(x => x.Manufacturer.Name == filter);
                }
            }

            if (!string.IsNullOrEmpty(sort))
            {
                if (sort != "Без сортировки")
                {
                    switch (sort)
                    {
                        case "По возрастанию цены":
                            products = products.OrderBy(x => x.Price);
                            break;
                        case "По убыванию цены":
                            products = products.OrderByDescending(x => x.Price);
                            break;
                    }
                }
            }

            Products.ItemsSource = products.ToList();
            CountOutput.Text = $"{products.Count()}/{_entities.Product.Count()}";
        }

        private void SearchInput_TextChanged(object sender, TextChangedEventArgs e)
        {
            RefreshProducts(SearchInput.Text, FilterInput.Text, SortInput.Text);
        }

        private void FilterInput_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RefreshProducts(SearchInput.Text, e.AddedItems[0] as string, SortInput.Text);
        }

        private void SortInput_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RefreshProducts(SearchInput.Text, FilterInput.Text, e.AddedItems[0] as string);
        }
    }
}
