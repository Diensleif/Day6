﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using WSUniversalLib;

namespace WSUniversalLibUnitTestProject
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void WrongProductType()
        {
            int productType = 0;
            int materialType = 1;
            int count = 1;
            float width = 100;
            float length = 100;

            Calculation calculation = new Calculation();
            int quantity = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(-1, quantity);
        }

        [TestMethod]
        public void WrongMaterialType()
        {
            int productType = 1;
            int materialType = 0;
            int count = 1;
            float width = 100;
            float length = 100;

            Calculation calculation = new Calculation();
            int quantity = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(-1, quantity);
        }

        [TestMethod]
        public void WrongCount()
        {
            int productType = 1;
            int materialType = 1;
            int count = 0;
            float width = 100;
            float length = 100;

            Calculation calculation = new Calculation();
            int quantity = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(-1, quantity);
        }

        [TestMethod]
        public void WrongWidth()
        {
            int productType = 1;
            int materialType = 1;
            int count = 1;
            float width = 0;
            float length = 100;

            Calculation calculation = new Calculation();
            int quantity = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(-1, quantity);
        }

        [TestMethod]
        public void WrongLength()
        {
            int productType = 1;
            int materialType = 1;
            int count = 1;
            float width = 100;
            float length = 0;

            Calculation calculation = new Calculation();
            int quantity = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(-1, quantity);
        }

        [TestMethod]
        public void FirstProductType()
        {
            int productType = 1;
            int materialType = 1;
            int count = 1;
            float width = 100;
            float length = 100;

            Calculation calculation = new Calculation();
            int quantity = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(11034, quantity);
        }

        [TestMethod]
        public void SecondProductType()
        {
            int productType = 2;
            int materialType = 1;
            int count = 1;
            float width = 100;
            float length = 100;

            Calculation calculation = new Calculation();
            int quantity = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(25076, quantity);
        }

        [TestMethod]
        public void ThirdProductType()
        {
            int productType = 3;
            int materialType = 1;
            int count = 15;
            float width = 20;
            float length = 45;

            Calculation calculation = new Calculation();
            int quantity = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(114148, quantity);
        }

        [TestMethod]
        public void FirstMaterialType()
        {
            int productType = 1;
            int materialType = 1;
            int count = 1;
            float width = 100;
            float length = 100;

            Calculation calculation = new Calculation();
            int quantity = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(11034, quantity);
        }

        [TestMethod]
        public void SecondMaterialType()
        {
            int productType = 1;
            int materialType = 2;
            int count = 1;
            float width = 100;
            float length = 100;

            Calculation calculation = new Calculation();
            int quantity = calculation.GetQuantityForProduct(productType, materialType, count, width, length);

            Assert.AreEqual(11014, quantity);
        }
    }
}
